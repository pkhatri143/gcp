# Component inventory

**Token sources:** `tokens.css` is built from two independent Figma
extractions: the original Variables export (`Color_Tokens.zip`,
`Primitives.zip`, `Typography_Tokens.zip`, `Spacing.zip`, `Radius.zip`)
and a later extraction via a third-party tool, typeui.sh (`DESIGN.md`),
which supplied the named typography scale and shadow tokens the first
export was missing. Two small color-value discrepancies between the two
sources are logged in known-issues.md rather than silently resolved.

Categorized from the initial audit of the uploaded component set. The
primitive/pattern/app-specific split is a best guess from naming and
content — confirm and correct as you go, don't treat it as final.

Status legend:
- **tokenized** — refactored to use the repo-root `tokens.css`, spot-checked
  against Figma.
- **needs tokenizing** — still has hardcoded hex/px values.
- **needs design pass** — tokenizing alone won't make this match Figma; the
  component itself is missing styling (see `Select.vue` in known-issues.md).
- **not yet audited** — not looked at yet.

## Activity / change-history (new — extracted while building the Equipment Change History screen)

| Component | Status |
|---|---|
| Avatar.vue | tokenized — no new-token gaps, built entirely from existing semantic color pairs |
| ActivityItem.vue | tokenized — body text rendered as pre-wrapped plain text pending confirmation of real data shape (see known-issues.md) |
| ActivityFeed.vue | tokenized — two-column connector is a placeholder divider, not confirmed functional design (see known-issues.md) |
| PageHeader.vue | tokenized — action-row icons (AI Insights, org chart, CML) are approximated, not the real icon set |
| Tabs.vue | **updated, not new** — extended to accept optional per-tab dropdown indicator (`{label, hasDropdown}`), backward compatible with existing plain-string usage in AlgorithmMappingPage.vue |

## App-shell / layout (new — extracted while building the AAM.106 screen)

| Component | Status |
|---|---|
| Sidebar.vue | **outdated — rebuild pending.** Single state; latest Figma (node 9636:10957) has Collapsed, Expanded, App Extended, Project Extended. See known-issues.md |
| TopBar.vue | tokenized; avatar initials colour is a `NEEDS TOKEN` literal (black) |
| Breadcrumbs.vue | tokenized |
| Tabs.vue | tokenized |
| IconButton.vue | tokenized |
| SearchInput.vue | tokenized |
| EmptyState.vue | tokenized |
| SelectField.vue | tokenized — new styled select, see note in the file; not a replacement for Select.vue, which still needs its own migration decision |

## Primitives (generic, reusable, no business-domain coupling)

| Component | Status |
|---|---|
| Button.vue | tokenized |
| Input.vue | tokenized |
| Select.vue | needs design pass |
| Textarea.vue | not yet audited |
| Switch.vue | not yet audited |
| RadioGroup.vue | not yet audited |
| SegmentedButton.vue | not yet audited |
| Label.vue | not yet audited |
| DatePicker.vue | not yet audited |
| Dropdown.vue | not yet audited |
| CustomDropdown.vue | not yet audited |
| ComboBox.vue | not yet audited |
| ObjectDropdown.vue | not yet audited |
| multiCheckDropdown.vue | not yet audited — also rename to `MultiCheckDropdown.vue` |
| InputOption.vue | not yet audited |
| FilterButton.vue | not yet audited |
| ProgressBar.vue | not yet audited |
| ProgressIndicator.vue | not yet audited |
| Loading.vue | not yet audited |
| ToastMessage.vue | not yet audited |
| SemanticMessage.vue | not yet audited |
| MessageDialog.vue | not yet audited |
| HoverTooltip.vue | not yet audited |
| ProfileThumbnail.vue | not yet audited |
| MathText.vue | not yet audited |
| BreadCrumbs.vue | not yet audited |
| PageTitle.vue | not yet audited |
| NotificationMenu.vue | not yet audited |
| side-navigation-panel.vue | not yet audited — also rename to `SideNavigationPanel.vue` |

## Patterns (composite, still generic — not tied to one business domain)

| Component | Status |
|---|---|
| DataTable.vue | not yet audited |
| Table.vue | not yet audited |
| customTreeTable.vue | not yet audited — also rename to `TreeTable.vue` |
| SearchAndFilter.vue | not yet audited |
| SearchBar.vue | not yet audited |
| FileUploader.vue | not yet audited |
| ImagePreview.vue | not yet audited |
| ImagePreviewDialog.vue | not yet audited |
| PreviewModal.vue | not yet audited |
| Chart.vue | not yet audited |
| ChartColorPicker.vue | not yet audited |
| ChartSidebar.vue | not yet audited |
| Heatmap.vue | not yet audited |
| LongitudinalGraph.vue | not yet audited |
| donutchart.vue | not yet audited — also rename to `DonutChart.vue` |
| Widget.vue | not yet audited |
| AppWidget.vue | not yet audited |
| CatalogPreviewTile.vue | not yet audited |
| DetailHeader.vue | not yet audited |
| DetailsDialog.vue | not yet audited |
| HeaderBar.vue | not yet audited |

## App/domain-specific (tied to Workflow / Inspection / Analytics / Asset concepts — candidates to keep OUT of a reusable design system package)

| Component |
|---|
| AnalyticsChartBuilder.vue |
| AnalyticsChartTable.vue |
| AnalyticsConfigPanel.vue |
| AssignDocumentModal.vue |
| CircumferentialCTP.vue |
| CreateAnalyticsSidebar.vue |
| CreateExpression.vue |
| ExpressionBuilderSidebar.vue |
| InspectionUploadImagePopup.vue |
| IntelliEditModal.vue |
| UploadDialog.vue |
| UploadImagePopup.vue |
| ViewAttachments.vue |
| ViewAttachmentsModal.vue |
| WorkflowApprovalDialog.vue |
| WorkflowApprovalRejectDialog.vue |
| inspectionDocumentImage.vue |
| workflowStatusInfoBtn.vue |
