# Known issues

Confirmed drift between code and the Figma source, and gaps in the token
set itself. Add to this file as you find more — don't let findings live
only in chat history.

## Confirmed code/Figma drift

- **Button disabled color mismatch.** `Button.vue`'s `.neutral` (disabled)
  background was hardcoded to `#9CA5BE` (Neutral/300, a grey). Figma's
  actual `button-disabled` token is `#9DA5FF` (States/Blue 70, a muted
  blue). Fixed in the tokenized version to use `--color-button-disabled`.
  **Still needs confirmation from whoever owns the Figma file** on which
  one is actually correct — the code and design may have both drifted from
  an original intent neither fully preserves.

- **Button medium arrow spacing off-scale.** `margin-left: 6px` on the
  medium arrow icon isn't on the spacing scale (nearest tokens are 4px /
  8px). Rounded down to 4px (`--primitive-space-2`) — confirm whether 6px
  was intentional and needs its own token, or was always meant to be 4/8.

## Token-set gaps (not code bugs — the token set itself is incomplete)

- ~~**Typography semantic tier is mostly missing.**~~ **RESOLVED** — a
  separate extraction (`DESIGN.md`, via a third-party tool called
  typeui.sh) supplied the full named type scale: Header 1–5, Sub Header
  1–3, Body Large/Medium/Small, Button Large/Medium/Compact, Tag 1–2,
  Link 1–2. Added to `tokens.css` as grouped `--font-{style}-size` /
  `-line-height` / `-weight` custom properties. Not yet applied to any
  component's CSS — that's the next step, same as when any new token
  lands: find components using raw primitive font values and swap them
  to the semantic style that matches.
- ~~**No shadow token...**~~ **RESOLVED** — `DESIGN.md` supplied real
  shadow tokens (`--shadow-highlighted-1..4`, `--shadow-regular-1..4`),
  now applied to `SelectField.vue`'s dropdown menu. The tooltip
  inverse-surface gap (`#333`/`#fff` in `Button.vue`) is still open — no
  surface-inverse / text-inverse color pair has turned up in any export
  yet.

## Discrepancies between data sources — needs a human decision, not a silent merge

`DESIGN.md` (a separate Figma extraction via a third-party tool) disagrees
with the original `Color_Tokens.zip` export on two values. Kept the
original export's values in `tokens.css` since it came directly from
Figma's own Variables export rather than a third-party re-extraction, but
this is a guess at which is more current, not a confirmed answer:

| Token | Original export | DESIGN.md | Using |
|---|---|---|---|
| `semantic-bg-red` | `#ffecee` | `#ffeceb` | original (`#ffecee`) |
| `semantic-element-orange` | `#ec6e0e` | `#e36a0d` | original (`#ec6e0e`) |

Both are small enough to be re-export/rounding drift rather than a real
design change, but don't assume that — confirm against the live Figma
file before trusting either blindly.

- **No dedicated tokens for input validation states.** `Input.vue`'s
  edited/external-value border colors are borrowed from the chart
  "Indicator/Accent" palette (`Accent 9` = `#C600BF`, `Accent 8` =
  `#F5CC00`) rather than real semantic input-state tokens. Works today by
  coincidence of hex values existing, but couples input styling to an
  unrelated token family. Needs real tokens like
  `--color-input-border-edited` / `--color-input-border-external` added at
  the Figma source.

- **No tooltip/inverse-surface tokens.** `Button.vue`'s tooltip uses
  hardcoded `#333` background / `#fff` text with no matching
  "surface-inverse" / "text-inverse" pair in the exported set.

- **Typo in the raw Figma variable name.** The Color Tokens export
  contains a token literally named `buttton-pressed` (three t's). Not
  fixed in `tokens.css` (renamed to `--color-button-pressed` there), but
  needs correcting at the Figma source so future exports don't reintroduce
  the typo under a different alias.

- **Inconsistent naming inside the token set itself.** Most raw variable
  names are kebab-case, but a few contain literal spaces (`text-large
  text`, `text-primary button`, `semantic button-error hover`). Same class
  of problem as the component file-naming inconsistency — fix at the
  Figma source before it multiplies across more exports.

## Gaps flagged while building the Change History screen

- **Activity body text has implicit structure, not confirmed.** The
  source screenshot's activity entries contain lines like "Criticality :
  B" and "Note : ..." that read like key/value data, not free text.
  Rendered as pre-wrapped plain text in ActivityItem.vue for now — if
  this feed is backed by structured fields, it should become a real
  key/value list instead of a text blob. Needs confirmation from
  whoever owns this data.
- **Two-column connector meaning unconfirmed.** The vertical line with
  small circular icons between the two activity columns in the
  screenshot has no specified purpose (thread linking? sync marker?).
  ActivityFeed.vue renders a plain visual divider as a placeholder —
  flag with design/product before treating this as final.
- **Action-row icons approximated.** AI Insights, org-chart, and CML
  icons in PageHeader.vue's action slot are generic placeholders, not
  the real icon set — swap once real icons/assets are available.

## Code Connect: earlier diagnosis was wrong — corrected

**What I previously logged here (now retracted):** that Button isn't a
real Figma Component Set, just a frame of similarly-named layers, and
that this was why Code Connect "succeeded" but had no effect.

**What's actually true:** the published library lists Button (and Radio
button, Segmented Button, Checkboxes, Cell, Columns, Tree Table Columns)
as `component_set` assets. The Figma MCP's metadata view simply shows a
component set as a `<frame>` whose children are `<symbol>` nodes
(symbol = component), which I misread as "plain frame + loose layers".

**The real cause of the failed mapping was targeting, not structure:**
- Mapping the `Buttons` *section* (3564:29373) failed with "Published
  component not found" — a section isn't a component.
- Mapping a single *variant* (252:7) reported success but the map read
  back empty.
- Mapping the *component set* itself (252:9) works: Code Connect then
  holds a mapping for all 45 variants at once
  (`get_code_connect_map` returns every variant -> `components/Button.vue`).

**Now verified, with a caveat:** a later `get_design_context` call on the
FFSA.108 Prescreening frame returned `import Button from
"components/Button.vue"` with each toolbar button wrapped as a Code
Connect snippet, so the mapping does change what gets generated. The
caveat: the props it passes are Figma's variant property names
(`content`, `size="Large"`, `state="Enabled"`, `type="Tertiary"`,
`iconLeft`, ...), not `Button.vue`'s real API (`text`,
`btnBackgroundType`, `size`, `arrow`). The mapping has no prop template,
so generated usage won't run against `Button.vue` as-is. Fix: add a
Code Connect template that translates Figma variant props to the Vue
props, or rename Button.vue's props to match.

**Other facts confirmed on this connection:** the account is on an
Organization-tier plan (not Enterprise, so the Variables REST API
remains unavailable), and `get_metadata` only lists the `Cover` page
even though deep node IDs elsewhere in the file are readable — the page
listing is incomplete, not the file.

**Next steps:** map the other component sets (Radio button, Segmented
Button, Checkboxes, etc.) by their component-set node IDs, and check
whether a Code Connect template (props -> Vue attributes) is needed for
`get_design_context` to actually use the mapping.

## Corrections from reading the live Figma frame (FFSA.108 Prescreening)

Reading real design context (not screenshots) resolved several things
previously logged as gaps or guessed:

- **Sidebar and AI button navy is a real token.** It is
  `color/primary/blue-10` (`#020631`, already `--primitive-color-blue-10`),
  not the `#14123f` literal used in Sidebar.vue, the FFS and AAM pages.
  `Sidebar.vue` and `TopBar.vue` now use the token / corrected avatar
  styling; the earlier standalone HTML pages (algorithm-mapping,
  ffs-assessments, ffsa-prescreening v1) still use the old literals —
  superseded by the v2 pages for the last two.
- **Avatar pink is a real token.** Profile thumbnail uses `#f5baff`
  (`--primitive-color-indicator-accent-4`) with a 1px `neutral-300`
  border, 48px, black 20px semibold initials. TopBar.vue's text colour
  (`accent-9`) was a guess and is wrong.
- **`chevron_down` exists.** The library has `chevron_down/Small`
  (24px). The earlier "no chevron_down in the inventory" gap came from
  the Icons-page export being incomplete. The paperclip and save icons
  are also used via icon swaps, so they exist too; their names weren't
  readable from that output.
- **Breadcrumb is 14px**, not 16px. Active tab: `semantic-bg/blue` fill
  plus a 2px `blue-50` underline; inactive tabs carry a 2px `neutral-100`
  underline.
- **Stat boxes** use a 2px left border in `indicator/accent-1`,
  `accent-2` and `semantic-element/grey` respectively, with the
  `Regular 1` shadow.
- **Shadow token bug (mine, fixed).** `tokens.css` had shadow offsets
  written as `0 2px Npx`. The Figma effect styles are offset (2, 4), so
  they should be `2px 4px Npx` (Regular 2 is the exception: `0 4px 10px`).
  Fixed in tokens.css; any repo copy pushed earlier has the wrong values.

## Sidebar (Side Navigation Panel) — rebuild pending

The latest design is the `Side Navigation Panel` frame, library file
`dyyiBTD6tJ57ggwSZToFbY`, node `9636:10957`. Its metadata shows four states,
each 925px tall:

| State | Node | Width |
|---|---|---|
| Collapsed | `9636:10958` | 72px |
| Expanded | `9636:10850` | 258px |
| App Extended | `9636:11112` | 735px |
| Project Extended | `9846:8368` | 735px |

**Only names and sizes have been read.** Styling, labels, icons and behaviour
have not (the Figma tools were unavailable when this was logged). Do not
guess them.

`Sidebar.vue` is outdated: it is a single state, 72px wide, built from a
screenshot. Separately, the two v2 HTML prototypes (FFS list, FFSA
Prescreening) contain their own hand-written 108px sidebar, copied from an
older Figma instance. The latest collapsed state is 72px, so those
prototypes' page layouts assume the wrong width. Rebuild the component from
the four states above with `figma-to-page`, update `Sidebar` in
`components.md`, then regenerate the prototypes.

## Token guard status

`scripts/check-tokens.sh` passes. Seven lines are marked
`token-exempt: NEEDS TOKEN` (find them with `grep -rn "NEEDS TOKEN"`), five
distinct gaps: tooltip inverse surface and text (Button.vue), pure black for
disabled text and focus border (Input.vue), literal black avatar initials
(TopBar.vue), and a translucent white for inactive nav icons (Sidebar.vue).
These need real tokens from design, not invented values.

`tokens.css` must exist once, at the repo root. Never keep a second copy.

## Components needing a design pass, not just tokenizing

- **Select.vue** — has exactly one styled rule (`font-family`); everything
  else is the browser's native `<select>` rendering. No visual parity with
  a Figma "Select"/"Dropdown" component yet. Needs to actually be built
  out against the Figma spec.
