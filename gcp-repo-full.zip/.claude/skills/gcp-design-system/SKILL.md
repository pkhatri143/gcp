---
name: gcp-design-system
description: Use this skill whenever writing, reviewing, or refactoring UI code (Vue components, styles, or markup) for the GCP Design System / Andora asset-integrity app. Covers the token system (color, typography, spacing, radius), component naming conventions, and the known gaps/drift between the Figma source and the current codebase. Trigger this for any task involving Button, Input, Select, or other components in this library, any request to "match the design system," "use the tokens," "check this against Figma," or build/refactor/style any component in this app — even if the user doesn't say "design system" explicitly.
---

# GCP Design System

This skill packages what's known about the GCP Design System so components are
built consistently instead of re-deriving colors, spacing, and conventions by
eye each time.

## Core rule: components never use raw values

Every color, spacing, radius, and font value in a component must resolve to a
CSS custom property from the repo-root `tokens.css` — never a literal hex, px,
or font-family string. That file is the single source of truth: import it once
globally, and never create a second copy of it anywhere (including inside this
skill folder).

```css
/* WRONG */
background: #4353ff;
padding: 8px 12px;

/* RIGHT */
background: var(--color-button-default);
padding: var(--button-padding-y) var(--button-padding-x);
```

Typography and shadows have named semantic styles too (`--font-header-1-*`,
`--font-body-medium-*`, `--shadow-regular-2`, etc.) — use the style that
matches the design intent (a page title gets `--font-header-*`, not a raw
`--primitive-font-size-*`) rather than reaching for primitives directly.

The token file has two tiers — read the repo-root `tokens.css` directly, don't
guess token names from memory:
- **Primitives** (`--primitive-*`) — raw scale values. Never reference these
  directly in a component.
- **Semantic** (`--color-*`, `--font-*`, `--radius-*`, `--button-*`) —
  purpose-named tokens that alias primitives. Components only ever reference
  these.

If a value in a design or an existing component doesn't map cleanly to any
token (e.g. a spacing value that isn't on the 2/4/8/12/16/20/24/32/40/48px
scale), don't invent a token or silently round it — flag it to the user and
ask whether it's intentional or needs a new token added at the Figma source.

## Before touching any component

1. Check `references/components.md` for that component's current status
   (tokenized / needs tokenizing / needs an actual design/build pass — some
   components, like `Select.vue`, have almost no real styling yet and
   tokenizing alone won't make them match Figma).
2. Check `references/known-issues.md` for confirmed drift between the code
   and the Figma source, so you don't re-introduce a value that's already
   been flagged as wrong.
3. Apply the naming convention below to any new file.

## Naming conventions

The existing codebase mixes PascalCase, camelCase, and kebab-case file names
(`Button.vue`, `customTreeTable.vue`, `side-navigation-panel.vue`). New or
refactored components should use:
- **PascalCase filenames** for every component (`TreeTable.vue`, not
  `customTreeTable.vue`).
- **camelCase props and emitted event names.**
- One export per component file — don't alias two different files to the
  same name in an index/barrel file (this codebase currently does that with
  `DocumentUploadPopup` / `InspectionUploadImagePopup` both pointing at
  `UploadImagePopup.vue` — treat that as a bug to flag, not a pattern to
  copy).

Flag (don't silently rename) any existing file you touch that violates this
— renaming existing files can break imports elsewhere in the app.

## Component split

Keep genuinely reusable primitives (Button, Input, Select, Table, Switch,
etc.) conceptually separate from app/domain-specific components (anything
named after Workflow, Inspection, Analytics, CML, FFS, or Asset concepts).
`references/components.md` has the current best-guess split — when adding a
new component, decide which bucket it belongs in and say so.

## When you find new drift or gaps

This skill is meant to accumulate findings, not just state them once. If you
discover a hardcoded value with no matching token, a color/spacing mismatch
against the Figma source, or a component that's more "needs building" than
"needs tokenizing," add it to `references/known-issues.md` in the same
format as the existing entries, so the next person (or agent) doesn't
rediscover it from scratch.

## Reference files

- `references/components.md` — inventory of all components, their category
  (primitive / pattern / app-specific), and their token-migration status.
- `references/known-issues.md` — confirmed drift between code and Figma,
  and gaps in the token set itself (e.g. missing typography roles).
- `tokens.css` (repo root, not in this folder) — the single source of truth for
  tokens. Read it; do not copy it.
