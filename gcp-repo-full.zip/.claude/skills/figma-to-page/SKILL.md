---
name: figma-to-page
description: Build a new page, screen or component in this repo from a Figma link. Use whenever the user pastes a figma.com/design URL (usually with a node-id), or asks to implement, build or recreate a screen, page or frame from Figma, even if they do not mention a skill.
---

# Build a page from a Figma link

Read `CLAUDE.md` first. Then read `.claude/skills/gcp-design-system/references/components.md`
(what already exists) and `known-issues.md` (what is already known to be wrong or missing).

## 0. Check the connection
Run `/mcp`. The Figma server must show as connected. If the Figma tools are not available,
stop and tell the user to follow `CLAUDE-CODE-SETUP.md`. Do not build from a screenshot alone.

## 1. Parse the link
`https://www.figma.com/design/<fileKey>/<name>?node-id=5527-61102`
- `fileKey` is the segment after `/design/`.
- `nodeId` is the `node-id` value with `-` replaced by `:` (`5527:61102`).
The server is link-based: it reads the file key and node id, it does not browse the page.

## 2. Read the design in pieces
1. Call `get_metadata` on the node. This gives structure only.
2. Call `get_design_context` on the node. **Full-page frames are often too large**: the tool
   then returns only sparse metadata. When that happens, call it on sub-layers instead:
   shell/title row, toolbar, table header, then ONE cell per column type and one row per state
   (default, alternate, selected). Do not read every repeated row.
3. Take a screenshot of the node for visual reference.
4. Text inside component instances (table cell text, labels) may not come through. Say where
   each piece of sample data came from. Never present guessed copy as design content.

## 3. Map to what already exists
- If the output contains `CodeConnectSnippet` / an import from `components/...`, use that
  component. **Translate Figma variant props to the component's real props.** Figma emits
  names like `type="Tertiary"`; check the `.vue` file for the actual API. Never pass Figma
  names through blindly.
- Otherwise search `components/` for an equivalent before creating anything.
- Figma emits `var(--some/token, #fallback)`. Map the token name to `tokens.css`. Never copy
  the fallback hex. If no token exists, use the closest one, add `/* NEEDS TOKEN: why */`,
  and log it in `known-issues.md`. Do not invent token values.
- The generated code is React + Tailwind. Convert it to Vue 3 `<script setup>` with scoped CSS
  using our tokens. Do not add Tailwind.

## 4. Build
- Reusable pieces: `components/PascalCase.vue`. The page itself: `components/XxxPage.vue`.
- Define hover, focus-visible, disabled for every interactive element. If Figma does not
  design a state, implement a sensible one and list it as an assumption.
- Use real semantics: `<button>`, `<label>`, `<fieldset>/<legend>` for radio groups, table
  `scope` and `aria-sort`, visible focus indicators, keyboard operability.
- Icons: use the library's real icon names (see `docs/DESIGN.md`, Icon Inventory). If the MCP
  can export the SVG, save it into the repo. Do not hand-draw icons when the real one exists.
- Images: MCP asset URLs expire after about 7 days. Never hotlink them. Save the files.

## 5. Verify, honestly
- Compare against the screenshot at the frame's width and list any differences you see.
- Run `scripts/check-tokens.sh` and fix new hard-coded colours.
- Do not claim the result matches the design unless you compared it.

## 6. Record and report
- Add new gaps to `known-issues.md` and new components to `components.md`.
- Finish with three short lists: **from Figma**, **assumed**, **open questions for design**.

## Traps already hit in this project
- Code Connect: map the **component set** node, not a single variant or a section.
- The page list may show only "Cover", yet nodes elsewhere in the file are reachable by id.
- Two exports can disagree on small colour values. Flag it, do not silently pick one.
- A hidden layer in Figma (`hidden="true"`) is not part of the design. Skip it and ask.
